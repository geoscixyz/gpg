GPG: Geophysics for Practicing Geoscientists
============================================

A learning resource for applied geophysics.

Originally created by Francis H.M. Jones and Douglas W. Oldenburg.

http://gpg.geosci.xyz/en/latest/