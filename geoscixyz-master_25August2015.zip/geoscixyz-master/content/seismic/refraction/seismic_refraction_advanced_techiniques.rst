c.. _seismic_refraction_advanced_techniques:

..<<place holder>>  This is a placeholder for the advanced techniques section. Instructions as of 05/10/2014 are to leave this section for now and give priority to other sections. The "Examples" section of the GPG is also to be omitted for now (Phil, 11/10/2014).