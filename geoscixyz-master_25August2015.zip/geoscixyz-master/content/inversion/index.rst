.. _inversion_index:

Inversion Notes
===============

Contents:

.. toctree::
   :maxdepth: 1
   
   inversion_basics
   inversion_overview
   inversion_discretization
